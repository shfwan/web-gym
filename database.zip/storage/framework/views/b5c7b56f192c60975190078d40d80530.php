<div class="w-full p-2 bg-white sticky top-0 z-50 shadow">
    <div class="w-full inline-flex items-center justify-between">
        <div class="inline-flex">
            <figure class="max-w-16">
                <img class="flex-[1_0_100%]"
                    src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg"
                    alt="">
            </figure>
            <h1 class="text-3xl font-bold text-yellow-300">GYM Alfatih</h1>
        </div>
        <nav class="inline-flex gap-4 items-center">
            <ul class="inline-flex gap-4 text-black">
                <?php if (isset($component)) { $__componentOriginal018f876e6458d8fa2c8d25080ee205fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navlink','data' => ['href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/']); ?>Home <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $attributes = $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $component = $__componentOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
                <?php if(Auth::user()): ?>
                    <?php if (isset($component)) { $__componentOriginal018f876e6458d8fa2c8d25080ee205fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navlink','data' => ['href' => '/pelatih']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/pelatih']); ?>Pelatih <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $attributes = $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $component = $__componentOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal018f876e6458d8fa2c8d25080ee205fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navlink','data' => ['href' => '/booking']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/booking']); ?>Booking <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $attributes = $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $component = $__componentOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal018f876e6458d8fa2c8d25080ee205fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navlink','data' => ['href' => '/profil']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/profil']); ?>Profil <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $attributes = $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $component = $__componentOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal018f876e6458d8fa2c8d25080ee205fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navlink','data' => ['href' => '/logout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/logout']); ?>Logout <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $attributes = $__attributesOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__attributesOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc)): ?>
<?php $component = $__componentOriginal018f876e6458d8fa2c8d25080ee205fc; ?>
<?php unset($__componentOriginal018f876e6458d8fa2c8d25080ee205fc); ?>
<?php endif; ?>
                <?php endif; ?>
            </ul>
            <button class="btn btn-warning rounded-md text-white " onclick="route('/login')">
                <a href="/login">Login</a>
            </button>
        </nav>
    </div>
</div>
<?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/components/top-navigation.blade.php ENDPATH**/ ?>