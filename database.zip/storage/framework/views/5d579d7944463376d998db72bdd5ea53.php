<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id' => '',
    'fullname' => '',
    'picture' => '',
    'phone' => '',
    'email' => '',
    'description' => '',
    'status' => '',
    'created_at' => '',
    'expire' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id' => '',
    'fullname' => '',
    'picture' => '',
    'phone' => '',
    'email' => '',
    'description' => '',
    'status' => '',
    'created_at' => '',
    'expire' => null,
]); ?>
<?php foreach (array_filter(([
    'id' => '',
    'fullname' => '',
    'picture' => '',
    'phone' => '',
    'email' => '',
    'description' => '',
    'status' => '',
    'created_at' => '',
    'expire' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div id="" class="card card-compact min-w-72 bg-white shadow-md rounded-md">
    <div class="w-full bg-yellow-100  h-32 rounded-t-md inline-flex p-4 gap-4 items-center">
        <figure id="image-view" class="max-w-24 border-white border-2 rounded-full bg-gray-300 cursor-pointer">
            <img class="flex-[1_0_100%] object-cover aspect-square" src="<?php echo e($picture != "" ? asset('storage/upload/' . $picture) : asset('/icon/account.png')); ?>"
                alt="profil">
        </figure>
        <div class="block w-full">
            <h3 class="card-title text-gray-800"><?php echo e($fullname); ?></h3>
        </div>
    </div>
    <div class="card-body items-start text-start gap-6">
        <div class="block space-y-2 w-full">
            <div class="inline-flex flex-col gap-2 w-full">
                <label for="label" class="text-sm text-gray-500">Phone</label>
                <h2 class="text-base text-gray-700"><?php echo e($phone); ?></h2>
            </div>
            <div class="inline-flex flex-col gap-2 w-full">
                <label for="label" class="text-sm text-gray-500">Email</label>
                <h2 class="text-base text-gray-700"><?php echo e($email); ?></h2>
            </div>
            <div class="inline-flex flex-col gap-2 w-full">
                <label for="label" class="text-sm text-gray-500">Description</label>
                <p class="truncate w-full text-base text-gray-700"><?php echo e($description == '' ? '-' : $description); ?></p>
            </div>
            <div class="inline-flex flex-col gap-2 w-full">
                <label for="label" class="text-sm text-gray-500">Status Member</label>
                <div class="badge <?php echo e($status ? 'badge-success' : 'badge-error'); ?> text-white">
                    <?php echo e($status ? 'Aktif' : 'Tidak Aktif'); ?>

                </div>
            </div>
            <div class="inline-flex flex-col gap-2 w-full">
                <label for="label" class="text-sm text-gray-500">Berlaku Dari</label>
                <h3 class="truncate w-full text-base text-gray-700">
                    <?php echo e($created_at == '' ? '-' : $created_at); ?></h3>
                <label for="label" class="text-sm text-gray-500">Sampai</label>
                <h3 class="truncate w-full text-base text-gray-700">
                    <?php echo e($expire == '' ? '-' : $expire); ?></h3>
            </div>
        </div>

        <div class="card-actions justify-end w-full">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-fit','id' => 'image'.e($id).'']); ?>
    <img class="flex-[1_0_100% max-w-xl rounded-md aspect-square object-cover size-full bg-gray-300"
        src="<?php echo e(asset('storage/upload/' . $picture)); ?>" alt="image" class="rounded-md" />

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>

<script type="text/javascript" hidden>
    document.getElementById("image-view").onclick = () => {
        document.getElementById("image<?php echo e($id); ?>").showModal()
    }
</script>
<?php /**PATH C:\laragon\www\gym\resources\views/components/cardmember.blade.php ENDPATH**/ ?>