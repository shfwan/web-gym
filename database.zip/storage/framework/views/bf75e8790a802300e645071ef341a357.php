<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id' => '',
    'title' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id' => '',
    'title' => '',
]); ?>
<?php foreach (array_filter(([
    'id' => '',
    'title' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<dialog id="<?php echo e($id); ?>" class="modal bg-black/30">
    <div class="modal-box min-w-fit w-fit">
        <form method="dialog">
            <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
        </form>
        <div class="relative block w-full space-y-4">
        <h3 class="text-lg font-bold text-center"><?php echo e($title); ?></h3>
        <hr>
            <?php echo e($slot); ?>

        </div>
    </div>
</dialog>
<?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/components/modal.blade.php ENDPATH**/ ?>