<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => '',
    'value' => '',
    'type' => 'text',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => '',
    'value' => '',
    'type' => 'text',
]); ?>
<?php foreach (array_filter(([
    'label' => '',
    'value' => '',
    'type' => 'text',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="flex flex-col gap-2 border rounded-md p-4">
    <label class="font-normal text-sm text-gray-700" for="label"><?php echo e($label); ?></label>
    <h1 class="font-medium text-black text-lg truncate">
        <?php if($type == 'number'): ?>
            Rp. <?php echo number_format($value, 0, ',','.'); ?>
        <?php else: ?>
            <?php echo e($value); ?>

        <?php endif; ?>
    </h1>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/text.blade.php ENDPATH**/ ?>