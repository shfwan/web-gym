<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => '',
    'name' => '',
    'value' => '',
    'type' => 'text',
    'placeholder' => '',
    'disabled' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => '',
    'name' => '',
    'value' => '',
    'type' => 'text',
    'placeholder' => '',
    'disabled' => false,
]); ?>
<?php foreach (array_filter(([
    'label' => '',
    'name' => '',
    'value' => '',
    'type' => 'text',
    'placeholder' => '',
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="block w-full  space-y-2">
    <label class="font-normal text-sm text-gray-700" for="label"><?php echo e($label); ?></label>
    <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>"
        <?php echo e($disabled ? 'disabled' : ''); ?>

        class="input input-bordered w-full max-w-full bg-transparent disabled:bg-gray-200 disabled:border-none disabled:text-gray-500 text-black  focus:bg-transparent"
        type="<?php echo e($type); ?>" placeholder="<?php echo e($placeholder); ?>" />
    
    <div class="max-w-2xl">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/input.blade.php ENDPATH**/ ?>