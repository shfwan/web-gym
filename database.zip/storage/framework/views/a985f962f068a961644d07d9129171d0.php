<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => '',
    'name' => '',
    'placeholder' => '',
    'value' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => '',
    'name' => '',
    'placeholder' => '',
    'value' => '',
]); ?>
<?php foreach (array_filter(([
    'label' => '',
    'name' => '',
    'placeholder' => '',
    'value' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="block w-full space-y-2">
    <label class="font-normal text-sm text-gray-700" for="label"><?php echo e($label); ?></label>
    <textarea name="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>"
        class="textarea textarea-bordered bg-white w-full text-black"><?php echo e($value); ?></textarea>
    <div class="max-w-2xl">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/textarea.blade.php ENDPATH**/ ?>