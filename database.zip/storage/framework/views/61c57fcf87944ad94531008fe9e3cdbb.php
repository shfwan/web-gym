<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id' => '',
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id' => '',
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]); ?>
<?php foreach (array_filter(([
    'id' => '',
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card bg-white rounded-md border hover:shadow transition-all min-h-20 md:min-w-full max-w-72 max-h-fit" onclick="<?php echo e($onclick); ?>">
    <figure class="p-4 cursor-pointer max-w-full" onclick="image<?php echo e($id); ?>.showModal()">
        <img class="flex-[1_0_100%] max-h-96 rounded-md aspect-square object-cover  bg-gray-300" src="<?php echo e(asset('storage/upload/' . $picture)); ?>" alt="image" class="rounded-md" />
    </figure>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-fit','id' => 'image'.e($id).'']); ?>
        <img class="flex-[1_0_100% max-w-xl rounded-md aspect-square object-cover bg-gray-300" src="<?php echo e(asset('storage/upload/' . $picture)); ?>" alt="image" class="rounded-md" />
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <div class="card-body items-start text-start">
        <h2 class="card-title sm:text-lg text-black truncate overflow-hidden"><?php echo e($name); ?></h2>
        <h2 class="text-gray-800">Rp. <?php echo number_format($price, 0, ',','.'); ?></h2>
        <p class="text-wrap overflow-hidden text-sm"><?php echo e($description == "" ? "Tidak ada deskripsi" : $description); ?></p>
        <div class="card-actions justify-end w-full">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/cardpelatih.blade.php ENDPATH**/ ?>