<aside class="fixed top-0 left-0 h-screen w-64 block place-items-center shadow p-4 bg-white space-y-4">
    <div class="w-full">
        <h1 class="text-2xl font-bold text-yellow-400 text-center">Gym Alfatih</h1>
    </div>
    <nav class="w-full">
        <ul class="block space-y-2">
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/dashboard']); ?>Dashboard <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/management']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/management']); ?>Pelatih <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/member']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/member']); ?>Member <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/transaksi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/transaksi']); ?>Transaction <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/riwayat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/riwayat']); ?>Riwayat <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/profil']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/profil']); ?>Profil <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/setting']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/setting']); ?>Setting <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/logout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/logout']); ?>Keluar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
        </ul>
    </nav>
</aside>
<?php /**PATH C:\laragon\www\gym\resources\views/components/side-navigation.blade.php ENDPATH**/ ?>