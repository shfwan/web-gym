<div id="top-navigation" class="w-full p-2 bg-white sticky top-0 z-50 shadow">
    <div class="w-full inline-flex items-center justify-between">
        <div class="inline-flex">
            <figure class="max-w-16">
                <img class="flex-[1_0_100%]"
                    src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg"
                    alt="">
            </figure>
            <h1 class="text-3xl font-bold text-yellow-300">GYM Alfatih</h1>
        </div>
        <nav class="inline-flex gap-4 items-center">
            <ul class="inline-flex gap-4 text-black items-center">
                <?php if(Auth::user()): ?>
                    <?php if (isset($component)) { $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $attributes; } ?>
<?php $component = App\View\Components\Navlink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navlink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/pelatih']); ?>Pelatih <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $attributes = $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $component = $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $attributes; } ?>
<?php $component = App\View\Components\Navlink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navlink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/transaksi']); ?>Trasanksi <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $attributes = $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $component = $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $attributes; } ?>
<?php $component = App\View\Components\Navlink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navlink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/profil']); ?>Profil <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $attributes = $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $component = $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $attributes; } ?>
<?php $component = App\View\Components\Navlink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navlink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/upgrade_member']); ?>Kartu Member <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $attributes = $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $component = $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginala9ec011aaeceb6ec556be9c2492b8454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-navlink','data' => ['href' => '/logout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('side-navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/logout']); ?>Keluar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $attributes = $__attributesOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__attributesOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454)): ?>
<?php $component = $__componentOriginala9ec011aaeceb6ec556be9c2492b8454; ?>
<?php unset($__componentOriginala9ec011aaeceb6ec556be9c2492b8454); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63 = $attributes; } ?>
<?php $component = App\View\Components\Navlink::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Navlink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/']); ?>Home <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $attributes = $__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__attributesOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63)): ?>
<?php $component = $__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63; ?>
<?php unset($__componentOriginal5a8d92aa9b7c8777043bf88836ff5c63); ?>
<?php endif; ?>
                    <button class="btn btn-warning rounded-md text-white ">
                        <a href="/logout">Login</a>
                    </button>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/top-navigation.blade.php ENDPATH**/ ?>