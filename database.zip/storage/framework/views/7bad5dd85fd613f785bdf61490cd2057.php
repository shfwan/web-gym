<?php $__env->startSection('content'); ?>
    <div
        class="<?php echo e(Auth::user()->role == 'member' ? 'container mx-auto max-w-7xl' : ''); ?> bg-white min-h-screen p-[2rem_4rem]">
        <div class="block w-full space-y-8 place-items-start">
            <div class="inline-flex items-center justify-between gap-4">
                <h1 class="font-semibold text-4xl text-black">Transaksi</h1>
                <select id="filter" class="select select-bordered ml-auto w-full max-w-xs bg-white text-black">
                    <option disabled selected>Filter Pembayaran</option>
                    <option>Semua</option>
                    <option>Booking</option>
                    <option>Card Member</option>
                </select>
            </div>

            <script type="text/javascript" hidden>
                let filter = document.getElementById('filter')
                filter.addEventListener('change', () => {
                    window.location.href = '/transaksi?filter=' + filter.value
                })
            </script>
            <div class="flex flex-col gap-4 w-full max-w-7xl">
                <div class="w-full grid grid-cols-6 border border-gray-300 p-4 gap-4 rounded-md place-items-center">
                    <h3 class="text-black font-semibold place-self-start truncate">
                        <?php echo e(Auth::user()->role == 'member' ? 'Nama Pelatih / Kartu Member' : 'Nama Member'); ?>

                    </h3>
                    <h3 class="text-black font-semibold">Harga</h3>
                    <h3 class="text-black font-semibold place-self-start">Tipe Pembayaran</h3>
                    <h3 class="text-black font-semibold">Status</h3>
                    <h3 class="text-black font-semibold">Tanggal</h3>
                    <h3 class="text-black font-semibold">Aksi</h3>
                </div>

                <?php if(count($listTransaksi) < 1): ?>
                    <div class="flex flex-col gap-8 w-full h-full items-center justify-center place-items-center">
                        <img class="max-w-96" src="/icon/empty.png" alt="">
                        <h1 class="font-semibold text-2xl text-gray-800">Saat ini tidak ada transaksi</h1>
                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = $listTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="w-full grid grid-cols-6 border border-gray-300 transition-all p-4 gap-4 rounded-md place-items-center">
                            <div class="place-self-start flex items-center justify-center h-full">
                                <?php if(auth()->user()->role == 'admin'): ?>
                                    <h3 class="text-black truncate ">
                                        <?php echo e($item->user->firstname . ' ' . $item->user->lastname); ?></h3>
                                <?php else: ?>
                                    <?php if($item->type == 'Booking'): ?>
                                        <h3 class="text-black truncate ">
                                            <?php echo e($item->pelatih ? $item->pelatih->name : 'Sudah dihapus'); ?></h3>
                                    <?php elseif($item->type == 'Card Member'): ?>
                                        <h3 class="text-black truncate ">
                                            <?php echo e($item->cardMember ? $item->cardMember->title : 'Sudah dihapus'); ?></h3>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <h3 class="text-black ">Rp. <?php echo number_format($item->total_price, 0, ',','.'); ?></h3>
                            <div class="place-self-start  h-full flex items-center justify-center">
                                <h3 class="text-black truncate"><?php echo e($item->type); ?></h3>
                            </div>
                            <?php if($item->pelatih || $item->cardMember): ?>
                                <?php if($item->status == 'accepted'): ?>
                                    <div class="badge badge-success text-white p-4">
                                        <?php echo e($item->status); ?>

                                    </div>
                                <?php elseif($item->status == 'pending'): ?>
                                    <div class="badge badge-warning text-white p-4">
                                        <?php echo e($item->status); ?>

                                    </div>
                                <?php else: ?>
                                    <div class="badge badge-error text-white p-4">
                                        <?php echo e($item->status); ?>

                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="badge badge-error text-white p-4">
                                    invalid
                                </div>
                            <?php endif; ?>
                            <h3 class="text-black place-self-center truncate text-ellipsis"><?php echo e($item->created_at); ?></h3>
                            <?php if($item->pelatih || $item->cardMember): ?>
                                <div class="place-self-center inline-flex gap-4">
                                    <?php if($item->status == 'pending'): ?>
                                        <button id=<?php echo e("pay-button.$item->id"); ?> type="submit"
                                            class="btn btn-info btn-sm w-fit text-white rounded">Bayar</button>

                                        <script id="" type="text/javascript" hidden>
                                            document.getElementById('pay-button.<?php echo e($item->id); ?>').onclick = function() {
                                                // SnapToken acquired from previous step
                                                snap.pay('<?php echo e($item->snap_token); ?>', {
                                                    // Optional
                                                    onSuccess: function(result) {
                                                        /* You may add your own js here, this is just example */
                                                        window.location.href = '<?php echo e(route('transaction.success', $item->id)); ?>';
                                                    },
                                                    // Optional
                                                    onPending: function(result) {
                                                        /* You may add your own js here, this is just example */
                                                        document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                                                    },
                                                    // Optional
                                                    onError: function(result) {
                                                        /* You may add your own js here, this is just example */
                                                        window.location.href = '<?php echo e(route('transaction.fail', $item->id)); ?>';

                                                    }
                                                });
                                            };
                                        </script>
                                    <?php else: ?>
                                        <button id="transaction-detail<?php echo e($item->id); ?>"
                                            class="btn btn-success btn-sm w-fit text-white rounded"
                                            onclick="detailTransaksi<?php echo e($item->id); ?>.showModal()">Lihat
                                            Transaksi</button>
                                        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'detailTransaksi'.e($item->id).'','title' => 'Detail Transaksi']); ?>
                                            <div class="flex flex-col gap-4  min-w-96 cursor-default">
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Transaksi ID','value' => ''.e($item->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php if($item->type == 'Booking'): ?>
                                                    <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Nama Pelatih / Kartu Member','value' => ''.e($item->pelatih ? $item->pelatih->name : 'Sudah dihapus').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php elseif($item->type == 'Card Member'): ?>
                                                    <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Nama Pelatih / Kartu Member','value' => ''.e($item->cardMember ? $item->cardMember->title : 'Sudah dihapus').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Tipe Pembayaran','value' => ''.e($item->type).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Tanggal Booking','value' => ''.e($item->date).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'status','title' => 'Status Pembayaran']); ?>
                                                    <?php if($item->pelatih || $item->cardMember): ?>
                                                        <?php if($item->status == 'accepted'): ?>
                                                            <div class="badge badge-success text-white p-4">
                                                                <?php echo e($item->status); ?>

                                                            </div>
                                                        <?php elseif($item->status == 'pending'): ?>
                                                            <div class="badge badge-warning text-white p-4">
                                                                <?php echo e($item->status); ?>

                                                            </div>
                                                        <?php else: ?>
                                                            <div class="badge badge-error text-white p-4">
                                                                <?php echo e($item->status); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <div class="badge badge-error text-white p-4">
                                                            invalid
                                                        </div>
                                                    <?php endif; ?>
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','title' => 'Total Harga','value' => ''.e($item->total_price).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal109ed44299a070e6f2e0a484dff15187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal109ed44299a070e6f2e0a484dff15187 = $attributes; } ?>
<?php $component = App\View\Components\Label::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Label::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','title' => 'Tanggal Transaksi','value' => ''.e($item->created_at).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $attributes = $__attributesOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__attributesOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal109ed44299a070e6f2e0a484dff15187)): ?>
<?php $component = $__componentOriginal109ed44299a070e6f2e0a484dff15187; ?>
<?php unset($__componentOriginal109ed44299a070e6f2e0a484dff15187); ?>
<?php endif; ?>
                                            </div>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>

                                        <script id="" type="text/javascript" hidden>
                                            document.getElementById('transaction-detail<?php echo e($item->id); ?>').onclick = () => {
                                                document.getElementById('detailTransaksi<?php echo e($item->id); ?>').showModal()
                                            }
                                        </script>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <h3 class="text-black place-self-center truncate text-ellipsis">Product tidak valid</h3>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($listTransaksi->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\gym\resources\views/pages/booking.blade.php ENDPATH**/ ?>