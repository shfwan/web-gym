<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]); ?>
<?php foreach (array_filter(([
    'picture' => '',
    'name' => '',
    'description' => '',
    'price' => 0,
    'onclick' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card bg-white rounded-md border hover:shadow transition-all min-w-72 cursor-pointer" onclick="<?php echo e($onclick); ?>">
    <figure class="px-4 pt-4">
        <img src="<?php echo e($picture); ?>" alt="Shoes" class="rounded-md" />
    </figure>
    <div class="card-body items-start text-start">
        <h2 class="card-title text-lg text-black"><?php echo e($name); ?></h2>
        <p class="text-wrap overflow-hidden text-sm"><?php echo e($description); ?></p>
        <h2 class="text-gray-800">Rp. <?php echo number_format($price, 0, ',','.'); ?></h2>
        <div class="card-actions justify-end w-full">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/components/cardpelatih.blade.php ENDPATH**/ ?>