<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center min-h-screen">
        <div class="min-w-96 min-h-fit shadow-md bg-white rounded-md p-8">
            <div class="block w-full place-content-center space-y-10">
                <h1 class="font-bold text-xl w-full text-center">Login</h1>
                <?php if($errors->any()): ?>
                    <div class="bg-red-400 rounded-md">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-col gap-4">
                        <input name="email" value="<?php echo e(old('email')); ?>" class="input input-bordered w-full max-w-full"
                            type="text" placeholder="Email atau Nomor Telepon" />
                        <input name="password" value="<?php echo e(old('password')); ?>" class="input input-bordered w-full max-w-full"
                            type="password" placeholder="Password" />
                        <button name="submit" type="submit" class="btn btn-lg w-full text-white btn-info">Login</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/pages/login.blade.php ENDPATH**/ ?>