<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => '',
    'description' => '',
    'image' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => '',
    'description' => '',
    'image' => '',
]); ?>
<?php foreach (array_filter(([
    'title' => '',
    'description' => '',
    'image' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card card-side bg-white rounded-md border hover:shadow transition-all min-w-72 max-h-32 cursor-pointer p-4">
    <figure class="p-2 max-w-20  bg-gray-100 rounded-md">
        <img class="" src="<?php echo e($image); ?>" alt="Shoes" class="rounded-md" />
    </figure>
    <div class="card-body items-start text-start">
        <h2 class="card-title text-xl font-bold text-black"><?php echo e($title); ?></h2>
        <div class="card-actions justify-end w-full">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/cardlatihan.blade.php ENDPATH**/ ?>