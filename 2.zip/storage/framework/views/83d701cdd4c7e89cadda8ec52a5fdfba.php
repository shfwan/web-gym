<footer class="footer text-white p-4 bg-yellow-400">
    <div class="w-full flex flex-col items-center justify-center">
        <h1 class="font-semibold">GYM Alfatih</h1>
        <h1 class="font-semibold">Copyright 2024 ©</h1>
    </div>
</footer>
<?php /**PATH C:\laragon\www\gym\resources\views/layouts/footer.blade.php ENDPATH**/ ?>