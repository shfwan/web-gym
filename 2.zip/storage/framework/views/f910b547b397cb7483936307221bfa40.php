<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-gray-100 w-full min-h-screen antialiased">
    
    <div class="flex">
        
        <div class="flex flex-col w-full">
            <?php echo $__env->make('components.top-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="flex-grow min-h-screen">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</body>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</html>
<?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/layouts/main.blade.php ENDPATH**/ ?>