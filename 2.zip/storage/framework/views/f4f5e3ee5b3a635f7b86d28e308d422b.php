<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['href' => '#']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href' => '#']); ?>
<?php foreach (array_filter((['href' => '#']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<li class="transition-all cursor-pointer rounded-md p-3  <?php echo e($href == "/logout" ? "bg-red-600 text-white" : "text-gray-800 hover:font-semibold hover:text-white hover:bg-yellow-400 hover:shadow"); ?>">
    <a class="w-full" href="<?php echo e($href); ?>"><?php echo e($slot); ?></a>
</li>
<?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/components/side-navlink.blade.php ENDPATH**/ ?>