<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => '',
    'count' => 0,
    'icon' => '',
    'type' => 'default',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => '',
    'count' => 0,
    'icon' => '',
    'type' => 'default',
]); ?>
<?php foreach (array_filter(([
    'title' => '',
    'count' => 0,
    'icon' => '',
    'type' => 'default',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="w-full min-h-36 shadow border rounded-md flex-row items-center justify-center p-4 gap-4">
    
    <img src="<?php echo e($icon); ?>" alt="">

    
    <div class="block w-full space-y-2 place-content-center h-full">
        <h3 class=" text-2xl text-center text-gray-700"><?php echo e($title); ?></h3>
        <?php if($type == 'currency'): ?>
        <h4 class=" text-2xl text-center text-gray-700">Rp. <?php echo number_format($count, 0, ',','.'); ?></h4>
        <?php else: ?>
        <h4 class=" text-2xl text-center text-gray-700"><?php echo e($count); ?></h4>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/cardstat.blade.php ENDPATH**/ ?>