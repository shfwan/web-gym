<?php $__env->startSection('content'); ?>
    <div class="container mx-auto max-w-7xl min-h-screen bg-white p-8">
        <div class="flex flex-col items-center justify-center gap-8">
            <div class="block place-items-center space-y-6">
                <h1 class="font-semibold text-2xl text-black">Pelatih yang Tersedia</h1>
                <div class="grid grid-cols-4 gap-4">
                    <?php for($i = 0; $i < 10; $i++): ?>
                        <?php if (isset($component)) { $__componentOriginal243bbc0719e60f716ad78cb05d96ccac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal243bbc0719e60f716ad78cb05d96ccac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cardpelatih','data' => ['picture' => ''.e('https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg').'','name' => 'Budiono Siregar','description' => 'Cita-cita Kapal Laut','price' => '100000','onclick' => 'pelatih.showModal()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cardpelatih'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['picture' => ''.e('https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg').'','name' => 'Budiono Siregar','description' => 'Cita-cita Kapal Laut','price' => '100000','onclick' => 'pelatih.showModal()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal243bbc0719e60f716ad78cb05d96ccac)): ?>
<?php $attributes = $__attributesOriginal243bbc0719e60f716ad78cb05d96ccac; ?>
<?php unset($__attributesOriginal243bbc0719e60f716ad78cb05d96ccac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal243bbc0719e60f716ad78cb05d96ccac)): ?>
<?php $component = $__componentOriginal243bbc0719e60f716ad78cb05d96ccac; ?>
<?php unset($__componentOriginal243bbc0719e60f716ad78cb05d96ccac); ?>
<?php endif; ?>
                    <?php endfor; ?>
                    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'pelatih','title' => 'Pelatih']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'pelatih','title' => 'Pelatih']); ?>
                        <div class="flex flex-col gap-4 max-w-3xl">
                            
                            <div class="inline-flex gap-4 w-full">
                                <figure class="max-w-20">
                                    <img class="flex-[1_0_100%]" src="" alt="">
                                </figure>
                                <div class="w-full block space-y-4">
                                    <h1 class="text-xl font-semibold">Budiono Siregar</h1>
                                    <h2 class="text-lg font-semibold">Rp. <?php echo number_format(20000, 0, ',','.'); ?></h2>
                                    <p class="max-w-96">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor, nemo
                                        obcaecati adipisci praesentium asperiores omnis culpa eaque? Quae mollitia quas illo
                                        ipsa, reprehenderit, delectus inventore ab voluptates consequatur, at unde?</p>
                                </div>
                            </div>

                            
                            

                            <div class="inline-flex w-full gap-4 justify-end">
                                <button class="btn btn-success btn-md text-white">
                                    Checkout
                                </button>
                            </div>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="join">
                <button class="join-item btn">1</button>
                <button class="join-item btn btn-active">2</button>
                <button class="join-item btn">3</button>
                <button class="join-item btn">4</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mingkii/5CD87119D870F31E/laragon/www/gym/resources/views/pages/pelatih.blade.php ENDPATH**/ ?>