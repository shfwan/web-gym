<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-gray-100 w-full min-h-screen antialiased">
    
    <script src="<?php echo e(env('MIDTRANS_URL')); ?>" data-client-key="<?php echo e(env('MIDTRANS_CLIENT_KEY')); ?>"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <div class="flex">
        <?php if(Auth::user() && Auth::user()->role == 'admin'): ?>
            <?php echo $__env->make('components.side-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="flex-grow ml-0 xl:ml-64 min-h-screen">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        <?php else: ?>
            <div class="flex flex-col w-full">
                <?php echo $__env->make('components.top-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="flex-grow min-h-screen">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <?php echo $__env->yieldContent('script'); ?>
</body>

<?php if(Auth::user() && Auth::user()->role == 'member'): ?>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


</html>
<?php /**PATH C:\laragon\www\gym\resources\views/layouts/main.blade.php ENDPATH**/ ?>