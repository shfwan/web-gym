<?php
$days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto max-w-7xl min-h-screen bg-white p-8">
        <div class="flex flex-col items-center justify-center gap-8">
            <div class="flex flex-col w-full place-items-center gap-6 min-h-screen">
                <h1 class="font-semibold text-2xl text-black">Pelatih yang Tersedia</h1>

                <div class="inline-flex gap-4 items-center justify-start min-w-full">
                    
                    <div class="place-self-start w-full">
                        <?php if (isset($component)) { $__componentOriginal465912bafb53d2799b51398725f2e117 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465912bafb53d2799b51398725f2e117 = $attributes; } ?>
<?php $component = App\View\Components\Search::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Search::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('pelatih.search')).'','name' => 'value','placeholder' => 'Cari Pelatih','value' => ''.e(old('value')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $attributes = $__attributesOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__attributesOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $component = $__componentOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__componentOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>
                    </div>

                    
                    <input id="date" class="input bg-transparent input-bordered text-white bg-warning" type="date"
                        name="date"
                        value="<?php echo e(app('request')->input('date') != null ? app('request')->input('date') : date('Y-m-d')); ?>">

                    <script type="text/javascript">
                        let date = document.getElementById('date');
                        date.addEventListener('change', () => {
                            window.location.href = "/pelatih?date=" + date.value;
                        })
                    </script>
                </div>

                <?php if(count($listPelatih) < 1): ?>
                    <div class="flex flex-col gap-8 w-full h-full items-center justify-center place-items-center">
                        <img class="max-w-96" src="/icon/empty.png" alt="">
                        <h1 class="font-semibold text-2xl text-gray-800">Tidak Ada Pelatih</h1>
                    </div>
                <?php endif; ?>
                <div class="grid grid-cols-4 gap-4">
                    <?php $__currentLoopData = $listPelatih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal79a3835c7abd0fb7b8187bb5e50bc6d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79a3835c7abd0fb7b8187bb5e50bc6d2 = $attributes; } ?>
<?php $component = App\View\Components\Cardpelatih::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cardpelatih'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Cardpelatih::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['picture' => ''.e($item->picture).'','name' => ''.e($item->name).'','description' => ''.e($item->description).'','price' => ''.e($item->price).'']); ?>

                            <button
                                class="btn btn-info rounded-md text-white" onclick="pelatih<?php echo e($item->id); ?>.showModal()">Lihat</button>
                            
                            
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79a3835c7abd0fb7b8187bb5e50bc6d2)): ?>
<?php $attributes = $__attributesOriginal79a3835c7abd0fb7b8187bb5e50bc6d2; ?>
<?php unset($__attributesOriginal79a3835c7abd0fb7b8187bb5e50bc6d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79a3835c7abd0fb7b8187bb5e50bc6d2)): ?>
<?php $component = $__componentOriginal79a3835c7abd0fb7b8187bb5e50bc6d2; ?>
<?php unset($__componentOriginal79a3835c7abd0fb7b8187bb5e50bc6d2); ?>
<?php endif; ?>

                        <script type="text/javascript"></script>

                        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6a555649da86b3de44465cdfe004aa4 = $attributes; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-fit','id' => 'pelatih'.e($item->id).'','title' => 'Pelatih']); ?>
                            <form class="flex flex-col gap-4" action="<?php echo e(route('transaction.checkout', $item->id)); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <div data class="flex flex-col items-center justify-center gap-4 min-w-96 max-w-3xl">
                                    
                                    <figure class="max-w-96 ">
                                        <img class="flex-[1_0_100%] rounded-md object-fill max-h-96"
                                            src="<?php echo e(asset('storage/upload/' . $item->picture)); ?>" alt="">
                                    </figure>

                                    <div class="w-full grid grid-cols-2 gap-4">
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Nama Pelatih','value' => ''.e($item->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Alamat','value' => ''.e($item->address).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','value' => ''.e($item->email).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Nomor HP','value' => ''.e($item->phone).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Harga','type' => 'number','value' => ''.e($item->price).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal186e1dd409d7e557d2e14049ed414178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal186e1dd409d7e557d2e14049ed414178 = $attributes; } ?>
<?php $component = App\View\Components\Text::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Terbooking','value' => ''.e($item->booking).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $attributes = $__attributesOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__attributesOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal186e1dd409d7e557d2e14049ed414178)): ?>
<?php $component = $__componentOriginal186e1dd409d7e557d2e14049ed414178; ?>
<?php unset($__componentOriginal186e1dd409d7e557d2e14049ed414178); ?>
<?php endif; ?>

                                        
                                    </div>

                                    <input name="id" type="text" value="<?php echo e($item->id); ?>" class="hidden">
                                    <input name="type" type="text" value="Booking" class="hidden">
                                    <input name="gym_id" type="text" value="<?php echo e($item->gym_id); ?>" class="hidden">
                                    <input name="price" type="text" value="<?php echo e($item->price); ?>" class="hidden">
                                    <input name="date" type="date"
                                        value="<?php echo e(app('request')->input('date') != null ? app('request')->input('date') : date('Y-m-d')); ?>"
                                        class="hidden">

                                    <label class="font-normal text-sm text-gray-700 text-start w-full" for="label">Hari
                                        yang Tersedia</label>
                                    <div class="inline-flex gap-4">

                                        <?php for($i = 0; $i < count($days); $i++): ?>
                                            <?php if(in_array($i, $item->available_days)): ?>
                                                <div id="update<?php echo e($i); ?>"
                                                    class="flex flex-col w-full p-4 items-center justify-center border rounded-md bg-success/80 text-white">
                                                    <input type="checkbox" name="days[]" value="<?php echo e($i); ?>"
                                                        id="update<?php echo e($days[$i]); ?>" checked hidden>
                                                    <h2><?php echo e($days[$i]); ?></h2>
                                                </div>
                                            <?php else: ?>
                                                <div id="update<?php echo e($i); ?>"
                                                    class="flex flex-col w-full p-4 items-center justify-center border rounded-md">
                                                    <input type="checkbox" name="days[]" value="<?php echo e($i); ?>"
                                                        id="update<?php echo e($days[$i]); ?>" hidden>
                                                    <h2><?php echo e($days[$i]); ?></h2>
                                                </div>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="inline-flex w-full gap-4 justify-end items-center">
                                    <label class="text-error font-semibold <?php echo e($item->statusAvailable ? 'hidden' : ''); ?>"
                                        for="">Tidak bisa Booking karena Sudah Penuh</label>
                                    <label class="text-error font-semibold <?php echo e($item->statusHari ? 'hidden' : ''); ?>"
                                        for="">Pelatih tidak tersedia untuk hari ini</label>
                                    <button type="submit"
                                        class="btn btn-success btn-md text-white <?php echo e($item->statusAvailable && $item->statusHari ? '' : 'btn-disabled'); ?>">
                                        Booking Sekarang
                                    </button>
                                </div>
                            </form>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $attributes = $__attributesOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__attributesOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" hidden>
        <?php if(session('success.checkout')): ?>
            Swal.fire({
                title: "Berhasil",
                text: "Berhasil checkout",
                icon: "success",
                confirmButtonColor: "#00a96e",
            })
        <?php endif; ?>

        <?php if(session('error.checkout')): ?>
            Swal.fire({
                title: "Gagal",
                text: "Gagal melakukan checkout",
                icon: "error",
                confirmButtonColor: "#ff5861",
            })
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\gym\resources\views/pages/pelatih.blade.php ENDPATH**/ ?>