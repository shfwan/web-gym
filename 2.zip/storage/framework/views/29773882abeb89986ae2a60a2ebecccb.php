<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => '',
    'value' => '',
    'type' => ['text', 'number', 'status'],
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => '',
    'value' => '',
    'type' => ['text', 'number', 'status'],
]); ?>
<?php foreach (array_filter(([
    'title' => '',
    'value' => '',
    'type' => ['text', 'number', 'status'],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="inline-flex justify-between items-center text-black">
    <label for="<?php echo e($title); ?>"><?php echo e($title); ?></label>
    <?php if($type == 'text'): ?>
        <h4 class=""><?php echo e($value); ?></h4>
    <?php elseif($type == 'number'): ?>
        <h4 class="">Rp. <?php echo number_format($value, 0, ',','.'); ?></h4>
    <?php elseif($type == 'status'): ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\gym\resources\views/components/label.blade.php ENDPATH**/ ?>